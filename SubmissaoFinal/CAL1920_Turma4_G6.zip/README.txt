# CAL-proj
Projeto de CAL 2019/2020 - Meat Wagons

Instruções de compilação:
Compilar e correr no CLion

Ficheiros de input necessários:
src/resources/buses.txt
src/resources/prisoners.txt
src/resources/TesteEspinho/edges.txt
src/resources/TesteEspinho/nodes.txt
src/resources/TesteEspinho/tags.txt
